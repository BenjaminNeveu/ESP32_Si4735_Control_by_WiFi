# Proof of Concept for SI4735 Arduino Library and ATtiny85 

It is a simple FM radio implementation. Test and validation of the SI4735 Arduino Library on ATtiny85.
This sketch has been successfully tested on __ATtiny85__.

<BR> 

See the youtube video [How to "SI4735 Arduino Library and ATtiny85"](https://youtu.be/zb9TZtYVu-s)

## Schematic

![Schematic ATtiny85 and Si4735](https://github.com/pu2clr/SI4735/blob/master/extras/images/attiny85_schematic.png)




