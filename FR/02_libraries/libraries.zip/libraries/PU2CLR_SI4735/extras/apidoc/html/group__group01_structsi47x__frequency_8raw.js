var group__group01_structsi47x__frequency_8raw =
[
    [ "FREQL", "group__group01.html#a858dfb4be81dfbd057aa63aded06bf3d", null ],
    [ "FREQH", "group__group01.html#a8836c6ec927c24305d2fd26a5aec2e2b", null ]
];