var group__group01_unionsi473x__gpio =
[
    [ "arg", "group__group01.html#af785eeee072dbe5d532fc7e76cd9e8eb", null ],
    [ "raw", "group__group01.html#ae560f6b01049205986b273a5c491081d", null ]
];