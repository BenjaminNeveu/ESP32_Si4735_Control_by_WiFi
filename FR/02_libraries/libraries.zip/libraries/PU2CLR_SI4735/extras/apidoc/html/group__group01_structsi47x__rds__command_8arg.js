var group__group01_structsi47x__rds__command_8arg =
[
    [ "INTACK", "group__group01.html#aa1b4c5526f2abe4a5d02be4016a44020", null ],
    [ "MTFIFO", "group__group01.html#a89ada8287a1cbe8c1cbcbaf629797e69", null ],
    [ "STATUSONLY", "group__group01.html#a0ad827114d7e2367674a05bbcdc53eda", null ],
    [ "dummy", "group__group01.html#a275876e34cf609db118f3d84b799a790", null ]
];