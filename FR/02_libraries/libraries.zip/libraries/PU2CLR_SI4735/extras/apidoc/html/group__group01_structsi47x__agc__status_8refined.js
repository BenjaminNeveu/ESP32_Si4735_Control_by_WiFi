var group__group01_structsi47x__agc__status_8refined =
[
    [ "STCINT", "group__group01.html#af8f21d801809287d578344911b65697c", null ],
    [ "DUMMY1", "group__group01.html#a3651c40ccc4450f2fc89fa3139dedd5a", null ],
    [ "RDSINT", "group__group01.html#a53d648e7e9d100d590e2f65ec7de079f", null ],
    [ "RSQINT", "group__group01.html#a8acf6c55c97050e7abd06c104012c77a", null ],
    [ "DUMMY2", "group__group01.html#abece94c62273dc7ecfabc565b76dbbe5", null ],
    [ "ERR", "group__group01.html#acd22bad976363fdd1bfbf6759fede482", null ],
    [ "CTS", "group__group01.html#ae16433ffd3adc248f0ce2608a95c3c76", null ],
    [ "AGCDIS", "group__group01.html#aeaad2cabb6417746b2dd432eda476f55", null ],
    [ "DUMMY", "group__group01.html#abd2103035a8021942390a78a431ba0c4", null ],
    [ "AGCIDX", "group__group01.html#a26bd0af30c189325bd004e10593eb5cd", null ]
];