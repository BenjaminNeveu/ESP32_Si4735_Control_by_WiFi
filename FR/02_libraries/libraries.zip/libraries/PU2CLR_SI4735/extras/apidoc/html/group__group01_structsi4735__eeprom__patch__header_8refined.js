var group__group01_structsi4735__eeprom__patch__header_8refined =
[
    [ "reserved", "group__group01.html#a327e0f8ef808c5d8c6072a07f0a26d26", null ],
    [ "status", "group__group01.html#a824abc0aadb3f2d4a53b915f10a2a60b", null ],
    [ "patch_id", "group__group01.html#a6672901531915ba41508c09a77f77a8d", null ],
    [ "patch_size", "group__group01.html#ac951249c14ef40b4436af008145347a9", null ]
];