var group__group01_structsi47x__rds__config_8arg =
[
    [ "RDSEN", "group__group01.html#af06feb780d38d7dc59d42878a3353c7f", null ],
    [ "DUMMY1", "group__group01.html#a3651c40ccc4450f2fc89fa3139dedd5a", null ],
    [ "BLETHD", "group__group01.html#a08e321d989e5154ff4e8a2b5d0fbb057", null ],
    [ "BLETHC", "group__group01.html#a1246c30829bddc4264fe51b0abc00dbe", null ],
    [ "BLETHB", "group__group01.html#a659adbc2d25b37801235e309fb25737f", null ],
    [ "BLETHA", "group__group01.html#a955ffa2ef1f258071376294e01482059", null ]
];