var group__group01_unionsi47x__antenna__capacitor =
[
    [ "raw", "group__group01.html#ab7ef1b0222904baf09a919e5704cdd44", null ],
    [ "value", "group__group01.html#aa59f9604df88a98b91295b0a9c009bbd", null ]
];