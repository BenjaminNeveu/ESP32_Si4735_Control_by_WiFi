var group__group01_unionsi47x__frequency =
[
    [ "raw", "group__group01.html#a238632206d118acac9b1ede44a0d3af6", null ],
    [ "value", "group__group01.html#aad12ac434ec9907e90a3f6b95377ca76", null ]
];