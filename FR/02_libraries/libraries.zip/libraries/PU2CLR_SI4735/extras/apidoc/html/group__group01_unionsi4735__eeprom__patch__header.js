var group__group01_unionsi4735__eeprom__patch__header =
[
    [ "refined", "group__group01.html#a206c5907140c242eff43969fdbf1ee39", null ],
    [ "raw", "group__group01.html#a94433975a0b1ff748a66a19e4125dc5e", null ]
];