var group__group01_structsi47x__tune__status_8arg =
[
    [ "INTACK", "group__group01.html#aa1b4c5526f2abe4a5d02be4016a44020", null ],
    [ "CANCEL", "group__group01.html#a2027c027133e22c8929e2874dc44dd36", null ],
    [ "RESERVED2", "group__group01.html#a0b5885d29a74762639e4b55c51ce2d85", null ]
];