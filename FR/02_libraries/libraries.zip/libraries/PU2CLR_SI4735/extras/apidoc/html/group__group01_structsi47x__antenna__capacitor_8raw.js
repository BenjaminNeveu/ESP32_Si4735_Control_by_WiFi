var group__group01_structsi47x__antenna__capacitor_8raw =
[
    [ "ANTCAPL", "group__group01.html#a0475bf71e813922e317ef7cb7b3df9fa", null ],
    [ "ANTCAPH", "group__group01.html#a5f437dbf77cdadcbb215ce5db44edbe6", null ]
];