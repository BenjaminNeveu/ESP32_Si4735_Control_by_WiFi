var group__group01_structsi47x__seek_8arg =
[
    [ "RESERVED1", "group__group01.html#ad8179a090910d4923b044cbce813c8ea", null ],
    [ "WRAP", "group__group01.html#ae1c8555fcf0ea2bb648a6fd527d658c0", null ],
    [ "SEEKUP", "group__group01.html#aed8a1fd68dec9364930b51d020ba07d6", null ],
    [ "RESERVED2", "group__group01.html#a0b5885d29a74762639e4b55c51ce2d85", null ]
];