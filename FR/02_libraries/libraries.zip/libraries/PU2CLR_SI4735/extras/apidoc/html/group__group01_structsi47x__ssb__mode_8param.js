var group__group01_structsi47x__ssb__mode_8param =
[
    [ "AUDIOBW", "group__group01.html#a38eda9266347ac0c0f09182baa2fefd0", null ],
    [ "SBCUTFLT", "group__group01.html#a5fd112c4d977a89cf8b7717ef0a12a9b", null ],
    [ "AVC_DIVIDER", "group__group01.html#a911ed778d046d0d22bf2df2938c1f084", null ],
    [ "AVCEN", "group__group01.html#a55576f7d4412f08280e49fba44ef707a", null ],
    [ "SMUTESEL", "group__group01.html#aeb7815cb295d531065f797c39cf36da5", null ],
    [ "DUMMY1", "group__group01.html#a3651c40ccc4450f2fc89fa3139dedd5a", null ],
    [ "DSP_AFCDIS", "group__group01.html#a5ff4a830553e8db4d36f8b3677e3d412", null ]
];