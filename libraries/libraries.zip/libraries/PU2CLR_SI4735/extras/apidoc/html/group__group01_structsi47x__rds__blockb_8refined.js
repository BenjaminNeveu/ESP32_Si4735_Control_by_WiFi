var group__group01_structsi47x__rds__blockb_8refined =
[
    [ "content", "group__group01.html#a9a0364b9e99bb480dd25e1f0284c8555", null ],
    [ "textABFlag", "group__group01.html#a652bfdc159637b708ac6e6f92d7650bc", null ],
    [ "programType", "group__group01.html#a264bd2c2ca8c895803767b0d39ff4a09", null ],
    [ "trafficProgramCode", "group__group01.html#a59e69d63ce38754ea53c4461b5cba1e2", null ],
    [ "versionCode", "group__group01.html#a20583dcf173525a78f726ef45329c5ae", null ],
    [ "groupType", "group__group01.html#a19223bd3731a4215ead3ba6a1eb8bbe8", null ]
];