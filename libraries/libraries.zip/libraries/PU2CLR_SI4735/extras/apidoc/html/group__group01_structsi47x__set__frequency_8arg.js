var group__group01_structsi47x__set__frequency_8arg =
[
    [ "FAST", "group__group01.html#adca6e617f6fb54033deb311e7e7c93cc", null ],
    [ "FREEZE", "group__group01.html#a1da4c7af6c0e106e2aec1c483252b329", null ],
    [ "DUMMY1", "group__group01.html#a3651c40ccc4450f2fc89fa3139dedd5a", null ],
    [ "USBLSB", "group__group01.html#a46ba89190297ccd0df7c8f8b5f72497f", null ],
    [ "FREQH", "group__group01.html#a8836c6ec927c24305d2fd26a5aec2e2b", null ],
    [ "FREQL", "group__group01.html#a858dfb4be81dfbd057aa63aded06bf3d", null ],
    [ "ANTCAPH", "group__group01.html#a5f437dbf77cdadcbb215ce5db44edbe6", null ],
    [ "ANTCAPL", "group__group01.html#a0475bf71e813922e317ef7cb7b3df9fa", null ]
];