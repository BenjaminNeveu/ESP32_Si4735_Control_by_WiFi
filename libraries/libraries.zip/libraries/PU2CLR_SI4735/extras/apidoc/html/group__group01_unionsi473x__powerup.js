var group__group01_unionsi473x__powerup =
[
    [ "arg", "group__group01.html#a1d76ab95c8f37f3ee9f2266e0a818455", null ],
    [ "raw", "group__group01.html#ab82e658c5816b0c31e32e100ff776ebe", null ]
];