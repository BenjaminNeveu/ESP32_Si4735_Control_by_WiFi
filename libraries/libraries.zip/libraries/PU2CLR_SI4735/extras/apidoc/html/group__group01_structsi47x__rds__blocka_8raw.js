var group__group01_structsi47x__rds__blocka_8raw =
[
    [ "highValue", "group__group01.html#aaee469db16fdff1aa5439b776b3d5860", null ],
    [ "lowValue", "group__group01.html#a72a22270b4e47acf046fad64a8720e4f", null ]
];