var group__group01_structsi47x__response__status_8resp =
[
    [ "STCINT", "group__group01.html#af8f21d801809287d578344911b65697c", null ],
    [ "DUMMY1", "group__group01.html#a3651c40ccc4450f2fc89fa3139dedd5a", null ],
    [ "RDSINT", "group__group01.html#a53d648e7e9d100d590e2f65ec7de079f", null ],
    [ "RSQINT", "group__group01.html#a8acf6c55c97050e7abd06c104012c77a", null ],
    [ "DUMMY2", "group__group01.html#abece94c62273dc7ecfabc565b76dbbe5", null ],
    [ "ERR", "group__group01.html#acd22bad976363fdd1bfbf6759fede482", null ],
    [ "CTS", "group__group01.html#ae16433ffd3adc248f0ce2608a95c3c76", null ],
    [ "VALID", "group__group01.html#ac9f1a6384b1c466d4612f513bd8e13ea", null ],
    [ "AFCRL", "group__group01.html#a4f37d8e1a484e1ac152858e71923f86c", null ],
    [ "DUMMY3", "group__group01.html#a613aa5c14b3ccc6304a519292c482ed1", null ],
    [ "BLTF", "group__group01.html#a4163d039102268d1b6ac272a25006d7f", null ],
    [ "READFREQH", "group__group01.html#a0d093ad5e587811b66f0047303ec86a9", null ],
    [ "READFREQL", "group__group01.html#ad667880f1209fa0da1d2c87c794329c7", null ],
    [ "RSSI", "group__group01.html#a6833f5d3374c1679bea428b50dbad9cc", null ],
    [ "SNR", "group__group01.html#a8dc5367d65459f69d78eb03e93f7703f", null ],
    [ "MULT", "group__group01.html#a36b0ca295026d76ee15df50dc4991e90", null ],
    [ "READANTCAP", "group__group01.html#aa4c3e6fac8670fa0b36ba68ff185aa24", null ]
];