var group__group01_unionsi47x__firmware__information =
[
    [ "resp", "group__group01.html#a4f71bb27ff0e3ba8de0412d43a63010e", null ],
    [ "raw", "group__group01.html#aa2ba7bbaa745c8ca18c83226246654e5", null ]
];