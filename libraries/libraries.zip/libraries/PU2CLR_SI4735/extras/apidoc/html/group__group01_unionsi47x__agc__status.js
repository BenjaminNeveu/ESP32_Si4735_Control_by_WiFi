var group__group01_unionsi47x__agc__status =
[
    [ "refined", "group__group01.html#aac4fc78ed4e4f265c74a9e50c2e63592", null ],
    [ "raw", "group__group01.html#a2f03c32a90a7991f2433bf8a5291885d", null ]
];