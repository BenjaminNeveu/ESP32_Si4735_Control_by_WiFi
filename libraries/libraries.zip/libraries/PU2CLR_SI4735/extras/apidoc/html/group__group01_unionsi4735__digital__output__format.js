var group__group01_unionsi4735__digital__output__format =
[
    [ "refined", "group__group01.html#a2f5af498b9dfe1e33765207842b3796d", null ],
    [ "raw", "group__group01.html#a0fa2c05d8877d3c680e904842993c33e", null ]
];