var group__group01_unionsi47x__firmware__query__library =
[
    [ "resp", "group__group01.html#a4b1bc1ed10aa884ede69b0ae5561cbba", null ],
    [ "raw", "group__group01.html#a5235c5b07b71d6dc4c76c275a091c63c", null ]
];