var group__group01_unionsi473x__gpio__ien =
[
    [ "arg", "group__group01.html#a41278f2e60bae96f74a825b4a741e273", null ],
    [ "raw", "group__group01.html#aa1d2b8d04e8ae43c085f8223b15812e9", null ]
];