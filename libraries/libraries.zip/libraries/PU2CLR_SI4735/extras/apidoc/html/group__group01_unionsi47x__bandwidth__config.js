var group__group01_unionsi47x__bandwidth__config =
[
    [ "param", "group__group01.html#a5da2dcc72ae3a6f0ced1aad7594362d5", null ],
    [ "raw", "group__group01.html#aa8fd81f2f62788fac6c3cce7b1ea765d", null ]
];