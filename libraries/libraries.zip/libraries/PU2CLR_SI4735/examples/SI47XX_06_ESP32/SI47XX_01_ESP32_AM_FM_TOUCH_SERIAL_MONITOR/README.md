# Proof of Concept for SI4735 Arduino Library 

## About SI4735_POC.ino

This project is a proof of concept for SI4735 device controlled by Arduino and the SI4735 Library. This Arduino Sketch only works on your IDE (Arduino IDE). However, you can replace the Serial Monitor functions that deal the SI4735 and arduino with functions that will manipulate the LCD, encoder and push buttons appropriated for your project.  


